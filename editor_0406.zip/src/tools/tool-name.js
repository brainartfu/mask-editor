export const ToolName = {
  ERASER: "eraser",
  IMAGE: "image",
  TEXT: "text",
  BACKGROUND: "background",
  SHADOW: "shadow",
  EFFECTS: "effects",
};

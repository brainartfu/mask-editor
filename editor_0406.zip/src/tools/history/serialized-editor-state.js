export const DEFAULT_SERIALIZED_EDITOR_STATE = {
  fonts: [],
};

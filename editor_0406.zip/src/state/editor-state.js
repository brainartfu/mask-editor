export const ActiveToolOverlay = {
  Filter: "filter",
  ActiveObject: "activeObj",
  Text: "text",
  ChangeImage: "changeImage",
  Crop: "crop",
  Resize: "resize",
  Image: "image",
  Background: "background",
  Shadow: "shadow",
  Effects: "effects",
};

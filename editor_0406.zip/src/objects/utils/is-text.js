export function isText(obj) {
  return obj?.type === "i-text";
}

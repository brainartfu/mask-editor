export const DEFAULT_OBJ_CONFIG = {
  lockScalingFlip: true,
  originY: "center",
  originX: "center",
  lockMovementX: true,
  lockMovementY: true,
  borderColor: "transparent",
};

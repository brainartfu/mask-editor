export const staticObjectConfig = {
  selectable: false,
  evented: false,
  lockMovementX: true,
  lockMovementY: true,
  lockRotation: true,
  lockScalingX: true,
  lockScalingY: true,
  lockUniScaling: true,
  hasControls: false,
  hasBorders: false,
  hasRotatingPoint: false,
  strokeWidth: 0,
};

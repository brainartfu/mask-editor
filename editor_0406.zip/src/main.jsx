import "./index.css";
import { SellerImageEditor } from "@/App";

SellerImageEditor.init({});

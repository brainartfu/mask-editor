import { ImageEditor } from "@/components/Editor";
import React from "react";

export default function EditorPage() {
  return (
    <div>
      <ImageEditor />
    </div>
  );
}
